IMPOSTER PARTY - ANDROID APK PROJECT

This project wraps the uploaded HTML app in an Android WebView.

PHONE-ONLY BUILD (NO CODING APP REQUIRED):
1. Create/sign in to a GitHub account in your mobile browser.
2. Create a new repository (for example: imposter-party-apk).
3. Upload the contents of this project into the repository root, including the .github folder.
4. Open the repository's Actions tab and run "Build Imposter Party APK" (or push to main).
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run, scroll to Artifacts, and download imposter-party-debug-apk.
7. Extract the downloaded artifact and install app-debug.apk on Android.

LOCAL BUILD OPTION:
- Import the project into a compatible Android IDE and run :app:assembleDebug.

Notes:
- The app needs INTERNET permission for Google Fonts and optional online/Firebase mode.
- The local game works from bundled assets.
- Firebase online mode still requires the configuration entered inside the app.
